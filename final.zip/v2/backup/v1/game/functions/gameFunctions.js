let movePlayer = () => {
    globalVars.player.moveUp(globalVars.actions.upPressed);
    for (entity of globalVars.parameters.entities) {
        if (globalVars.player.hitbox.checkCollision(entity.hitbox)) {
            globalVars.player.moveDown(true);
        }
    }
    for (player of globalVars.players) {
        if (globalVars.player.hitbox.checkCollision(player.hitbox)) {
            globalVars.player.moveDown(true);
        }
    }

    globalVars.player.moveDown(globalVars.actions.downPressed);
    for (entity of globalVars.parameters.entities) {
        if (globalVars.player.hitbox.checkCollision(entity.hitbox)) {
            globalVars.player.moveUp(true);
        }
    }
    for (player of globalVars.players) {
        if (globalVars.player.hitbox.checkCollision(player.hitbox)) {
            globalVars.player.moveUp(true);
        }
    }

    globalVars.player.moveLeft(globalVars.actions.leftPressed);
    for (entity of globalVars.parameters.entities) {
        if (globalVars.player.hitbox.checkCollision(entity.hitbox)) {
            globalVars.player.moveRight(true);
        }
    }
    for (player of globalVars.players) {
        if (globalVars.player.hitbox.checkCollision(player.hitbox)) {
            globalVars.player.moveRight(true);
        }
    }

    globalVars.player.moveRight(globalVars.actions.rightPressed);
    for (entity of globalVars.parameters.entities) {
        if (globalVars.player.hitbox.checkCollision(entity.hitbox)) {
            globalVars.player.moveLeft(true);
        }
    }
    for (player of globalVars.players) {
        if (globalVars.player.hitbox.checkCollision(player.hitbox)) {
            globalVars.player.moveLeft(true);
        }
    }
}

let movePlayers = () => {
    for (player of globalVars.players) {
        if (player.x < player.newX) {
            player.moveRight(true);
            if (player.hitbox.checkCollision(globalVars.player.hitbox)) {
                player.moveLeft(true);
            }
        }
        if (player.x > player.newX) {
            player.moveLeft(true);
            if (player.hitbox.checkCollision(globalVars.player.hitbox)) {
                player.moveRight(true);
            }
        }
        if (player.y < player.newY) {
            player.moveDown(true);
            if (player.hitbox.checkCollision(globalVars.player.hitbox)) {
                player.moveUp(true);
            }
        }
        if (player.y > player.newY) {
            player.moveUp(true);
            if (player.hitbox.checkCollision(globalVars.player.hitbox)) {
                player.moveDown(true);
            }
        }
        if (Math.sqrt((player.newX - player.x) * (player.newX - player.x) + (player.newY - player.y) * (player.newY - player.y)) > 10) {
            player.x = player.newX;
            player.y = player.newY;
        }
    }
}

let playerActions = () => {
    globalVars.player.jump(globalVars.actions.qPressed, globalVars.actions.ePressed, globalVars.actions.spacePressed, globalVars.mouseCoords);
}