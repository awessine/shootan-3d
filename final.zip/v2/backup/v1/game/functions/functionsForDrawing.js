let drawPlayer = () => {
    ctx.fillStyle = 'black';
    ctx.fillRect(globalVars.player.x, globalVars.player.y, globalVars.player.skin.width, globalVars.player.skin.height);
    ctx.font = '20px arial';
    ctx.textAlign = 'center';
    ctx.fillText(globalVars.player.name, globalVars.player.x + globalVars.player.skin.width / 2, globalVars.player.y - 10);
}
let drawPlayers = () => {
    ctx.fillStyle = 'violet';
    for (player of globalVars.players) {
        ctx.fillRect(player.x, player.y, player.skin.width, player.skin.height);
        ctx.font = '20px arial';
        ctx.textAlign = 'center';
        ctx.fillText(player.name, player.x + player.skin.width / 2, player.y - 10);
    }
}
let drawEntities = () => {
    ctx.fillStyle = 'gray'
    globalVars.parameters.entities.forEach(entity => {
        ctx.fillRect(entity.x, entity.y, entity.width, entity.height);
    });
}
let drawLoginScreen = () => {
    ctx.fillStyle = 'black';
    ctx.font = '40px arial';
    ctx.textAlign = 'center';
    ctx.fillText("ENTER YOUR NAME", canvas.width / 2, -75 + canvas.height / 2);
    ctx.fillText(globalVars.playerName + globalVars.pointer, globalVars.shift + canvas.width / 2, canvas.height / 2);
}
let clearCanvas = () => {
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    //ctx.clearCanvas(0, 0, canvas.width, canvas.height);
}