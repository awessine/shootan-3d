//LOGIN
let pointerTimer = () => { 
    if (globalVars.pointer === "") {
        globalVars.pointer = "_"
        globalVars.shift = 11;
    } else if (globalVars.pointer === "_") {
        globalVars.pointer = "";
        globalVars.shift = 0;
    }
};

//GAME
let drawTimer = () => {
    clearCanvas();
    if (globalVars.state === 'login') {
        drawLoginScreen();
    } else if (globalVars.state === 'online') {
        drawPlayers();
        drawPlayer();
        drawEntities();
    }
};
let gameTimer = () => {
    if (globalVars.state === 'online') {
        movePlayer();
        movePlayers();
        playerActions();
    }
};
let sendActionTimer = () => {
    if (globalVars.oldPlayerCoordinates.x !== globalVars.player.x || globalVars.oldPlayerCoordinates.y !== globalVars.player.y) {
        socket.emit('action', {
            action: 'move',
            player: globalVars.player
        });
    }
    
    globalVars.oldPlayerCoordinates.x = globalVars.player.x;
    globalVars.oldPlayerCoordinates.y = globalVars.player.y;
};