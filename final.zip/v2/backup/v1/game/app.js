/*window.onload = window.onresize = () => {
    canvas.width = document.documentElement.clientWidth * 0.998;
    canvas.height = document.documentElement.clientHeight  * 0.995;
    drawTimer();
}*/
canvas.width = 1400;
canvas.height = 800;

socket.on('connect', () => {
    globalVars.state = 'login';
    setInterval(pointerTimer, 500);
    setInterval(drawTimer, 5);

    document.addEventListener('keydown', loginKeyboardListener);
    document.addEventListener('keypress', loginTypingListener);
});

socket.on('online', data => {
    globalVars.state = 'online';
    clearInterval(pointerTimer);
    document.removeEventListener('keydown', loginKeyboardListener);
    document.removeEventListener('keypress', loginTypingListener);

    document.addEventListener('keydown', playerKeyDownListener);
    document.addEventListener('keyup', playerKeyUpListener);

    canvas.onmousemove = e => {
        globalVars.mouseCoords.x = e.offsetX;
        globalVars.mouseCoords.y = e.offsetY;
    }

    globalVars.parameters = data.parameters;
    globalVars.player = new Player(data.player);
    data.players.forEach(player => {
        globalVars.players.push(new Player(player));
    });
    for (player of globalVars.players) {
        if (player.id === globalVars.player.id) {
            globalVars.players.splice(globalVars.players.indexOf(player), 1);
        }
    }

    setInterval(gameTimer, 5);
    setInterval(sendActionTimer, 15);

    socket.on('update', data => {
        console.log(data);
        for (playerMessage of data) {
            if (playerMessage.action === 'connect') {
                globalVars.players.push(new Player(playerMessage.player));
            }
            if (playerMessage.action === 'move') {
                for (playerClient of globalVars.players) {
                    if (playerMessage.player.id === playerClient.id) {
                        playerClient.newX = playerMessage.player.x;
                        playerClient.newY = playerMessage.player.y;
                    }
                }
            }
            if (playerMessage.action === 'disconnect') {
                for (playerClient of globalVars.players) {
                    if (playerMessage.player.id === playerClient.id)
                        globalVars.players.splice(globalVars.players.indexOf(playerClient), 1);
                }
            }
        }
    
        for (player of globalVars.players) {
            if (player.id === globalVars.player.id) {
                globalVars.players.splice(globalVars.players.indexOf(player), 1);
            }
        }
        //console.log(data);
        //console.log(globalVars.players);
    });
});

socket.on('disconnect', () => {

});