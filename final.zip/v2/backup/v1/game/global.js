const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

const socket = io();

let globalVars = {
    state: "",
    playerName: "",
    pointer: "_",
    shift: 11,
    player: {},
    players: [],
    parameters: {},
    oldPlayerCoordinates: {},
    mouseCoords: {
        x: 0,
        y: 0
    },
    actions: {
        upPressed: false,
        downPressed: false,
        leftPressed: false,
        rightPressed: false,
        qPressed: false,
        ePressed: false,
        spacePressed: false
    }
};