class Player {
    constructor(player) {
        this.id = player.id;
        this.name = player.name;
        this.x = player.x;
        this.y = player.y;
        this.skin = player.skin;
        this.hitbox = new Hitbox(player.hitbox);
        this.step = player.step;
    }

    moveUp(upPressed) {
        if (upPressed) {
            this.y -= this.step;
            this.hitbox.updateHitbox(this);
        }
    }

    moveDown(downPressed) {
        if (downPressed) {
            this.y += this.step;
            this.hitbox.updateHitbox(this);
        }
    }

    moveLeft(leftPressed) {
        if (leftPressed) {
            this.x -= this.step;
            this.hitbox.updateHitbox(this);
        }
    }

    moveRight(rightPressed) {
        if (rightPressed) {
            this.x += this.step;
            this.hitbox.updateHitbox(this);
        }
    }

    jump(qPressed, ePressed, spacePressed, mouseCoords) {
        if (qPressed && ePressed && spacePressed) {
            this.x = mouseCoords.x;
            this.y = mouseCoords.y;
        }
    }
}