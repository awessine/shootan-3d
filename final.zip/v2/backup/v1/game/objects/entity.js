class Entity {

}