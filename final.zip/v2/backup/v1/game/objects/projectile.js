class Projectile {
    
}