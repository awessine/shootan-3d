const express = require('express');
const app = express();
const server = require('http').Server(app);
const io = require('socket.io')(server);

server.listen(53304);

let players = [];
let id = 0;
let parameters = {
    entities: [{
        x: 200,
        y: 300,
        width: 10,
        height: 300,
        hitbox: {
            x: 200,
            y: 300,
            width: 10,
            height: 300
        }
    }, {
        x: 200,
        y: 300,
        width: 300,
        height: 10,
        hitbox: {
            x: 200,
            y: 300,
            width: 300,
            height: 10
        }
    }, {
        x: 500,
        y: 300,
        width: 10,
        height: 100,
        hitbox: {
            x: 500,
            y: 300,
            width: 10,
            height: 100
        }
    }, {
        x: 500,
        y: 500,
        width: 10,
        height: 100,
        hitbox: {
            x: 500,
            y: 500,
            width: 10,
            height: 100
        }
    }, {
        x: 200,
        y: 600,
        width: 310,
        height: 10,
        hitbox: {
            x: 200,
            y: 600,
            width: 310,
            height: 10
        }
    }, {
        x: 1000,
        y: 700,
        width: 150,
        height: 10,
        hitbox: {
            x: 1000,
            y: 700,
            width: 100,
            height: 10
        }
    }, {
        x: 1000,
        y: 550,
        width: 10,
        height: 150,
        hitbox: {
            x: 1000,
            y: 550,
            width: 10,
            height: 150
        }
    }, {
        x: 1000,
        y: 550,
        width: 150,
        height: 10,
        hitbox: {
            x: 1000,
            y: 550,
            width: 150,
            height: 10
        }
    }, {
        x: 1150,
        y: 550,
        width: 10,
        height: 160,
        hitbox: {
            x: 1150,
            y: 550,
            width: 10,
            height: 160
        }
    }]
};
let updatedPlayers = [];

app.use(express.static(__dirname + '/game/'));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/game/game.html');
});

io.on('connection', (socket) => {
    socket.on('login', playerName => {
        let playerData = {
            id: id,
            name: playerName,
            x: 55 * id,
            y: 0,
            skin: {
                width: 50,
                height: 50
            },
            hitbox: {
                x: 0,
                y: 0,
                width: 50,
                height: 50
            },
            step: 1
        }

        socket.id = id;

        id++;

        players.push(playerData);
        updatedPlayers.push({
            action: 'connect',
            player: playerData
        });

        socket.emit('online', {
            parameters: parameters,
            player: playerData,
            players: players
        });

    });

    socket.on('disconnect', () => {
        for (i in players) {
            if (players[i].id === socket.id) {
                updatedPlayers.push({
                    action: 'disconnect',
                    player: players[i]
                });
                players.splice(i, 1);
                break;
            }
        }
    });

    socket.on('action', data => {
        if (data.action === 'move') {
            for (player of players) {
                if (data.player.id === player.id) {
                    players[players.indexOf(player)] = data.player;
                    updatedPlayers.push({
                        action: 'move',
                        player: data.player
                    });
                    break;
                }
            }
        }
    });
});

setInterval(() => {
    if (updatedPlayers.length !== 0)
        io.emit('update', updatedPlayers);
    updatedPlayers = [];
}, 15);

/*setInterval(() => {
    console.log(players)
}, 1000);*/