class Skin {
    constructor(width, height) {
        this.width = width;
        this.height = height;
    }
}